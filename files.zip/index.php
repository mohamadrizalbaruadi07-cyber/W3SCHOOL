<?php
require 'auth.php';
$judul = 'Belajar pemrograman';
include 'header.php';

$rak = mysqli_query($koneksi, "SELECT k.slug, k.nama, k.deskripsi, k.warna,
                                      (SELECT COUNT(*) FROM materi m WHERE m.id_kategori = k.id) AS jumlah
                               FROM kategori k ORDER BY k.id");
?>
<section class="hero">
    <div class="wadah">
        <div>
            <h1>Belajar menulis kode, lalu langsung mencobanya.</h1>
            <p>
                <?php if (sudah_login()): ?>
                    Halo, <?php echo e($_SESSION['user']['nama']); ?>. Pilih bahasa di bawah untuk melanjutkan belajar.
                <?php else: ?>
                    Materi singkat dan contoh kode untuk Python, SQL, Java, JavaScript, dan CSS. Gratis untuk dibaca.
                <?php endif; ?>
            </p>
            <?php if (!sudah_login()): ?>
                <a class="tombol tombol-inline" href="daftar.php">Buat akun</a>
            <?php endif; ?>
        </div>
        <div class="panel-kode" aria-hidden="true">
<pre class="kode">nama = "Sari"
umur = 17
print(nama, "berumur", umur)</pre>
            <div class="hasil">Sari berumur 17</div>
        </div>
    </div>
</section>

<section class="wadah">
    <div class="rak">
        <?php while ($b = mysqli_fetch_assoc($rak)): ?>
            <a class="bahasa" style="--warna:<?php echo e($b['warna']); ?>" href="materi.php?k=<?php echo e($b['slug']); ?>">
                <strong><?php echo e($b['nama']); ?></strong>
                <span><?php echo e($b['deskripsi']); ?></span>
                <small><?php echo (int)$b['jumlah']; ?> materi</small>
            </a>
        <?php endwhile; ?>
    </div>
</section>
<?php include 'footer.php'; ?>
