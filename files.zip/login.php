<?php
require 'auth.php';

if (sudah_login()) {
    header('Location: index.php');
    exit;
}

$galat = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = mysqli_prepare($koneksi, "SELECT nama, username, password, role FROM user WHERE username = ? LIMIT 1");
    mysqli_stmt_bind_param($stmt, "s", $username);
    mysqli_stmt_execute($stmt);
    $baris = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

    $cocok = false;
    if ($baris) {
        if (password_verify($password, $baris['password'])) {
            $cocok = true;
        } elseif (hash_equals($baris['password'], md5($password))) {
            // akun lama (md5): masuk, lalu ubah otomatis ke hash yang lebih aman
            $cocok = true;
            $baru = password_hash($password, PASSWORD_DEFAULT);
            $up = mysqli_prepare($koneksi, "UPDATE user SET password = ? WHERE username = ?");
            mysqli_stmt_bind_param($up, "ss", $baru, $baris['username']);
            mysqli_stmt_execute($up);
        }
    }

    if ($cocok) {
        session_regenerate_id(true);
        $_SESSION['user'] = [
            'nama'     => $baris['nama'],
            'username' => $baris['username'],
            'role'     => $baris['role'] ?? 'pelajar',
        ];
        $lg = mysqli_prepare($koneksi, "UPDATE user SET last_login = NOW() WHERE username = ?");
        mysqli_stmt_bind_param($lg, "s", $baris['username']);
        mysqli_stmt_execute($lg);

        header('Location: index.php');
        exit;
    }
    $galat = 'Username atau kata sandi tidak sesuai.';
}

$judul = 'Masuk';
include 'header.php';
?>
<div class="wadah">
    <form class="kartu-form" method="post">
        <h1>Masuk</h1>
        <p class="ket">Masuk untuk menyimpan progres belajar Anda.</p>

        <?php if (isset($_GET['daftar'])): ?>
            <div class="pesan ok">Pendaftaran berhasil. Silakan masuk.</div>
        <?php endif; ?>
        <?php if ($galat): ?>
            <div class="pesan galat"><?php echo e($galat); ?></div>
        <?php endif; ?>

        <label for="username">Username</label>
        <input type="text" id="username" name="username" value="<?php echo e($_POST['username'] ?? ''); ?>" required autofocus>
        <label for="password">Kata sandi</label>
        <input type="password" id="password" name="password" required>
        <button class="tombol" type="submit">Masuk</button>
        <p class="alih">Belum punya akun? <a href="daftar.php">Daftar</a></p>
    </form>
</div>
<?php include 'footer.php'; ?>
