<?php
// Sertakan file ini di baris paling atas setiap halaman: require 'auth.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/koneksi.php';

define('NAMA_SITUS', 'RuangKita'); // ganti nama situs di sini

// Folder bin milik JDK (untuk menjalankan Java). Kosongkan jika javac sudah ada di PATH.
// Contoh: 'C:/Program Files/Java/jdk-21/bin/'  (akhiri dengan garis miring)
define('JDK_BIN', '');

function e($teks) {
    return htmlspecialchars((string)$teks, ENT_QUOTES, 'UTF-8');
}
function sudah_login() {
    return isset($_SESSION['user']);
}
function is_admin() {
    return sudah_login() && (($_SESSION['user']['role'] ?? '') === 'admin');
}
function wajib_login() {
    if (!sudah_login()) {
        header('Location: login.php');
        exit;
    }
}
function wajib_admin() {
    wajib_login();
    if (!is_admin()) {
        http_response_code(403);
        die('Halaman ini khusus admin.');
    }
}
