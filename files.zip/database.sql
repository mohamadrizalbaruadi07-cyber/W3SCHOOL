-- Jalankan di phpMyAdmin > database belajar_web > tab SQL
-- (XAMPP memakai MariaDB, jadi "IF NOT EXISTS" aman dipakai)

-- 1) Tabel user: peran, last login, daerah, dan kolom password lebih panjang (untuk password_hash)
ALTER TABLE user
  MODIFY password VARCHAR(255) NOT NULL,
  ADD COLUMN IF NOT EXISTS provinsi   VARCHAR(100) NULL,
  ADD COLUMN IF NOT EXISTS kabupaten  VARCHAR(100) NULL,
  ADD COLUMN IF NOT EXISTS role       ENUM('admin','pelajar') NOT NULL DEFAULT 'pelajar',
  ADD COLUMN IF NOT EXISTS last_login DATETIME NULL;

-- 2) Tabel kategori & materi
CREATE TABLE IF NOT EXISTS kategori (
  id        INT AUTO_INCREMENT PRIMARY KEY,
  slug      VARCHAR(40)  NOT NULL UNIQUE,
  nama      VARCHAR(60)  NOT NULL,
  deskripsi VARCHAR(160) NOT NULL DEFAULT '',
  warna     VARCHAR(7)   NOT NULL DEFAULT '#2f6fed'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS materi (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  id_kategori INT          NOT NULL,
  judul       VARCHAR(150) NOT NULL,
  isi         MEDIUMTEXT   NOT NULL,
  kode_contoh MEDIUMTEXT   NULL,
  urutan      INT          NOT NULL DEFAULT 1,
  FOREIGN KEY (id_kategori) REFERENCES kategori(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3) Isi awal
INSERT INTO kategori (id, slug, nama, deskripsi, warna) VALUES
 (1,'python','Python','Bahasa serbaguna untuk web, data, dan otomatisasi.','#3776ab'),
 (2,'sql','SQL','Bahasa untuk mengambil dan mengelola data di database.','#d9822b'),
 (3,'java','Java','Bahasa berorientasi objek untuk aplikasi dan Android.','#c0392b'),
 (4,'javascript','JavaScript','Bahasa yang membuat halaman web bisa berinteraksi.','#c9a400'),
 (5,'css','CSS','Bahasa untuk mengatur tampilan halaman web.','#2965f1');

INSERT INTO materi (id_kategori, judul, isi, kode_contoh, urutan) VALUES
(1,'Pengenalan Python','<p>Python adalah bahasa pemrograman yang dikenal mudah dibaca. Python dipakai untuk membuat situs web, menganalisis data, dan mengotomatiskan tugas.</p><p>Program Python ditulis baris demi baris. Perintah <code>print()</code> menampilkan teks ke layar.</p>','print("Halo, dunia!")',1),
(1,'Variabel dan Tipe Data','<p>Variabel adalah wadah untuk menyimpan nilai. Di Python, variabel dibuat dengan tanda <code>=</code> tanpa perlu menulis tipenya.</p><p>Tipe data yang sering dipakai: teks (<code>str</code>), bilangan bulat (<code>int</code>), dan bilangan desimal (<code>float</code>).</p>','nama = "Sari"\numur = 17\nprint(nama, "berumur", umur)',2),
(2,'Pengenalan SQL','<p>SQL (Structured Query Language) dipakai untuk berbicara dengan database. Data disimpan dalam tabel yang terdiri dari baris dan kolom.</p><p>Perintah <code>SELECT</code> mengambil data dari tabel.</p>','SELECT * FROM siswa;',1),
(2,'SELECT dan WHERE','<p><code>SELECT</code> memilih kolom yang ingin ditampilkan. <code>WHERE</code> menyaring baris sesuai syarat.</p>','SELECT nama FROM siswa WHERE kelas = ''X'';',2),
(3,'Pengenalan Java','<p>Java adalah bahasa berorientasi objek yang dipakai untuk aplikasi desktop, server, dan Android. Setiap program Java berada di dalam sebuah <em>class</em>, dan dijalankan dari method <code>main</code>.</p>','public class Main {\n    public static void main(String[] args) {\n        System.out.println("Halo, dunia!");\n    }\n}',1),
(3,'Variabel di Java','<p>Java mewajibkan kita menulis tipe data saat membuat variabel, misalnya <code>int</code> untuk bilangan bulat dan <code>String</code> untuk teks.</p>','int umur = 17;\nString nama = "Sari";\nSystem.out.println(nama + " berumur " + umur);',2),
(4,'Pengenalan JavaScript','<p>JavaScript berjalan di browser dan membuat halaman web bisa merespons klik, mengisi formulir, dan menampilkan data tanpa memuat ulang halaman.</p>','console.log("Halo, dunia!");',1),
(4,'Variabel: let dan const','<p>Gunakan <code>let</code> untuk nilai yang bisa berubah, dan <code>const</code> untuk nilai yang tetap.</p>','const nama = "Sari";\nlet umur = 17;\numur = umur + 1;\nconsole.log(nama, umur);',2),
(5,'Pengenalan CSS','<p>CSS (Cascading Style Sheets) mengatur warna, ukuran, dan tata letak elemen HTML. Aturan CSS terdiri dari <em>selektor</em> dan blok properti.</p>','<style>\n  p { color: #c0392b; font-size: 20px; }\n</style>\n<p>Teks ini berwarna merah.</p>',1),
(5,'Selektor CSS','<p>Selektor menentukan elemen mana yang diberi gaya: nama elemen (<code>p</code>), kelas (<code>.judul</code>), atau id (<code>#utama</code>).</p>','<style>\n  .judul { color: #2965f1; }\n  #utama { background: #eef3ff; padding: 10px; }\n</style>\n<div id="utama">\n  <h2 class="judul">Halo CSS</h2>\n</div>',2);

-- 4) Jadikan akun Anda admin (ganti 'namaanda' dengan username Anda)
-- UPDATE user SET role='admin' WHERE username='namaanda';
