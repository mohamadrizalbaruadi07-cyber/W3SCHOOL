<?php
require 'auth.php';

$slug = $_GET['k'] ?? '';
$stmt = mysqli_prepare($koneksi, "SELECT id, slug, nama, warna FROM kategori WHERE slug = ?");
mysqli_stmt_bind_param($stmt, "s", $slug);
mysqli_stmt_execute($stmt);
$kat = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$kat) {
    http_response_code(404);
    $judul = 'Tidak ditemukan';
    include 'header.php';
    echo '<div class="wadah"><div class="kosong"><h1>Bahasa tidak ditemukan</h1><p><a href="index.php">Kembali ke beranda</a></p></div></div>';
    include 'footer.php';
    exit;
}

// semua materi pada kategori ini
$q = mysqli_prepare($koneksi, "SELECT id, judul, isi, kode_contoh FROM materi WHERE id_kategori = ? ORDER BY urutan, id");
mysqli_stmt_bind_param($q, "i", $kat['id']);
mysqli_stmt_execute($q);
$daftar = mysqli_fetch_all(mysqli_stmt_get_result($q), MYSQLI_ASSOC);

// materi yang sedang dibuka (default: yang pertama)
$idx = 0;
if (isset($_GET['m'])) {
    foreach ($daftar as $i => $mt) {
        if ((int)$mt['id'] === (int)$_GET['m']) { $idx = $i; break; }
    }
}
$materi = $daftar[$idx] ?? null;
$sebelum = $idx > 0 ? $daftar[$idx - 1] : null;
$sesudah = $idx < count($daftar) - 1 ? $daftar[$idx + 1] : null;

$kat_aktif = $kat['slug'];
$judul = $materi ? $materi['judul'] . ' - ' . $kat['nama'] : $kat['nama'];
include 'header.php';
?>
<div class="wadah">
<?php if (!$materi): ?>
    <div class="kosong">
        <h1>Materi <?php echo e($kat['nama']); ?> belum tersedia</h1>
        <p>Materi sedang disiapkan. Coba lagi nanti.</p>
    </div>
<?php else: ?>
    <div class="baca" style="--warna:<?php echo e($kat['warna']); ?>">
        <aside class="samping">
            <h2>Tutorial <?php echo e($kat['nama']); ?></h2>
            <?php foreach ($daftar as $mt): ?>
                <a href="materi.php?k=<?php echo e($kat['slug']); ?>&m=<?php echo (int)$mt['id']; ?>"
                   class="<?php echo $mt['id'] == $materi['id'] ? 'aktif' : ''; ?>"><?php echo e($mt['judul']); ?></a>
            <?php endforeach; ?>
        </aside>

        <article class="isi">
            <h1><?php echo e($materi['judul']); ?></h1>
            <?php echo $materi['isi']; /* ditulis oleh admin, jadi HTML-nya tidak di-escape */ ?>

            <?php if (!empty($materi['kode_contoh'])):
                $catatan = [
                    'python'     => 'Python berjalan di browser Anda (butuh internet saat pertama kali). Fungsi input() belum didukung.',
                    'sql'        => 'Memakai database contoh (SQLite) dengan tabel siswa(id, nama, kelas, nilai). Setiap kali dijalankan, data kembali ke awal.',
                    'java'       => 'Kode dikompilasi dan dijalankan di server. Nama class harus Main. Perlu login.',
                    'javascript' => 'Gunakan console.log() untuk menampilkan hasil.',
                    'css'        => 'Tulis HTML dan CSS bersama-sama, hasilnya tampil langsung.',
                ];
            ?>
                <h2>Coba sendiri</h2>
                <div class="editor" data-bahasa="<?php echo e($kat['slug']); ?>" style="--warna:<?php echo e($kat['warna']); ?>">
                    <div class="editor-bar">
                        <span>Editor <?php echo e($kat['nama']); ?></span>
                        <div class="aksi">
                            <button type="button" class="tombol-run" id="btn-run">&#9654; Jalankan</button>
                            <button type="button" class="tombol-reset" id="btn-reset">Reset</button>
                        </div>
                    </div>
                    <div class="editor-isi">
                        <textarea id="kode" spellcheck="false" autocomplete="off" aria-label="Editor kode"><?php echo e($materi['kode_contoh']); ?></textarea>
                        <div class="hasil-wadah">
                            <div class="hasil-judul">Hasil</div>
                            <iframe id="hasil-frame" sandbox="allow-scripts" title="Hasil" hidden></iframe>
                            <div id="hasil-teks" class="hasil-teks redup" aria-live="polite">Klik "Jalankan" untuk melihat hasil.</div>
                        </div>
                    </div>
                    <p class="catatan"><?php echo e($catatan[$kat['slug']] ?? ''); ?> Tab = indentasi, Ctrl+Enter = jalankan (Esc lalu Tab untuk pindah fokus).</p>
                </div>
                <script src="coba.js"></script>
            <?php endif; ?>

            <div class="navbab">
                <?php if ($sebelum): ?>
                    <a class="tombol-garis" href="materi.php?k=<?php echo e($kat['slug']); ?>&m=<?php echo (int)$sebelum['id']; ?>">&laquo; <?php echo e($sebelum['judul']); ?></a>
                <?php else: ?><span></span><?php endif; ?>
                <?php if ($sesudah): ?>
                    <a class="tombol-garis" href="materi.php?k=<?php echo e($kat['slug']); ?>&m=<?php echo (int)$sesudah['id']; ?>"><?php echo e($sesudah['judul']); ?> &raquo;</a>
                <?php endif; ?>
            </div>
        </article>
    </div>
<?php endif; ?>
</div>
<?php include 'footer.php'; ?>
