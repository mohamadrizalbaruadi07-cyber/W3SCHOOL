</main>
<footer class="kaki">
    <div class="wadah">&copy; <?php echo date('Y'); ?> <?php echo e(NAMA_SITUS); ?>. Belajar pemrograman dengan contoh yang bisa langsung dicoba.</div>
</footer>
</body>
</html>
