<?php
// Pakai: require 'auth.php'; $judul = '...'; include 'header.php';
// Opsional: $kat_aktif = 'python';  (menandai menu bahasa yang sedang dibuka)
$judul     = $judul ?? NAMA_SITUS;
$kat_aktif = $kat_aktif ?? '';
$menu_kat  = mysqli_query($koneksi, "SELECT slug, nama, warna FROM kategori ORDER BY id");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($judul); ?> - <?php echo e(NAMA_SITUS); ?></title>
    <link rel="stylesheet" href="belajar.css">
</head>
<body>
<header class="topbar">
    <div class="wadah">
        <a class="merek" href="index.php">
            <?php if (file_exists(__DIR__ . '/logo.png')): ?>
                <img src="logo.png" alt="">
            <?php else: ?>
                <span class="tanda">&lt;/&gt;</span>
            <?php endif; ?>
            <?php echo e(NAMA_SITUS); ?>
        </a>
        <nav class="menu" aria-label="Bahasa pemrograman">
            <?php while ($k = mysqli_fetch_assoc($menu_kat)): ?>
                <a href="materi.php?k=<?php echo e($k['slug']); ?>"
                   style="--warna:<?php echo e($k['warna']); ?>"
                   class="<?php echo $k['slug'] === $kat_aktif ? 'aktif' : ''; ?>"><?php echo e($k['nama']); ?></a>
            <?php endwhile; ?>
        </nav>
        <div class="akun">
            <?php if (sudah_login()): ?>
                <span><?php echo e($_SESSION['user']['nama']); ?></span>
                <span class="lencana"><?php echo e($_SESSION['user']['role'] ?? 'pelajar'); ?></span>
                <a class="tombol-kecil" href="logout.php">Keluar</a>
            <?php else: ?>
                <a href="login.php">Masuk</a>
                <a class="tombol-kecil" href="daftar.php">Daftar</a>
            <?php endif; ?>
        </div>
    </div>
</header>
<main>
