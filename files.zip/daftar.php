<?php
require 'auth.php';

if (sudah_login()) {
    header('Location: index.php');
    exit;
}

// Data wilayah (38 provinsi, 514 kabupaten/kota) dari wilayah.json
$file_wilayah = __DIR__ . '/wilayah.json';
if (!file_exists($file_wilayah)) {
    die('File wilayah.json tidak ditemukan di: ' . __DIR__);
}
$wilayah_json = file_get_contents($file_wilayah);

$galat = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama      = trim($_POST['nama'] ?? '');
    $username  = trim($_POST['username'] ?? '');
    $password  = $_POST['password'] ?? '';
    $provinsi  = trim($_POST['provinsi'] ?? '');
    $kabupaten = trim($_POST['kabupaten'] ?? '');

    if ($nama === '' || $username === '' || $password === '') {
        $galat = 'Nama, username, dan kata sandi wajib diisi.';
    } elseif (strlen($password) < 6) {
        $galat = 'Kata sandi minimal 6 karakter.';
    } elseif ($provinsi === '' || $kabupaten === '') {
        $galat = 'Pilih provinsi dan kabupaten/kota.';
    } else {
        $cek = mysqli_prepare($koneksi, "SELECT 1 FROM user WHERE username = ? LIMIT 1");
        mysqli_stmt_bind_param($cek, "s", $username);
        mysqli_stmt_execute($cek);
        if (mysqli_fetch_row(mysqli_stmt_get_result($cek))) {
            $galat = 'Username sudah dipakai. Coba username lain.';
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            // role tidak diambil dari form: akun baru selalu "pelajar" (default di database)
            $stmt = mysqli_prepare($koneksi, "INSERT INTO user (nama, username, password, provinsi, kabupaten) VALUES (?, ?, ?, ?, ?)");
            mysqli_stmt_bind_param($stmt, "sssss", $nama, $username, $hash, $provinsi, $kabupaten);
            if (mysqli_stmt_execute($stmt)) {
                header('Location: login.php?daftar=ok');
                exit;
            }
            $galat = 'Pendaftaran gagal. Coba lagi.';
        }
    }
}

$judul = 'Daftar';
include 'header.php';
?>
<div class="wadah">
    <form class="kartu-form" method="post">
        <h1>Buat akun</h1>
        <p class="ket">Akun pelajar gratis. Anda bisa langsung membaca dan mencoba materi.</p>

        <?php if ($galat): ?>
            <div class="pesan galat"><?php echo e($galat); ?></div>
        <?php endif; ?>

        <label for="nama">Nama</label>
        <input type="text" id="nama" name="nama" value="<?php echo e($_POST['nama'] ?? ''); ?>" required>
        <label for="username">Username</label>
        <input type="text" id="username" name="username" value="<?php echo e($_POST['username'] ?? ''); ?>" required>
        <label for="password">Kata sandi</label>
        <input type="password" id="password" name="password" minlength="6" required>

        <label for="provinsi">Provinsi</label>
        <select name="provinsi" id="provinsi" required>
            <option value="">Pilih provinsi</option>
        </select>
        <label for="kabupaten">Kabupaten/Kota</label>
        <select name="kabupaten" id="kabupaten" required disabled>
            <option value="">Pilih kabupaten/kota</option>
        </select>

        <button class="tombol" type="submit">Daftar</button>
        <p class="alih">Sudah punya akun? <a href="login.php">Masuk</a></p>
    </form>
</div>

<script>
    const wilayah = <?php echo $wilayah_json; ?>;
    const selProv = document.getElementById('provinsi');
    const selKab  = document.getElementById('kabupaten');
    const provLama = <?php echo json_encode($_POST['provinsi'] ?? ''); ?>;
    const kabLama  = <?php echo json_encode($_POST['kabupaten'] ?? ''); ?>;

    function isiKabupaten(namaProv, pilih) {
        selKab.innerHTML = '<option value="">Pilih kabupaten/kota</option>';
        const prov = wilayah.find(p => p.nama === namaProv);
        if (!prov) { selKab.disabled = true; return; }
        prov.kabupaten.forEach(k => {
            const o = document.createElement('option');
            o.value = o.textContent = k;
            if (k === pilih) o.selected = true;
            selKab.appendChild(o);
        });
        selKab.disabled = false;
    }

    wilayah.forEach(p => {
        const o = document.createElement('option');
        o.value = o.textContent = p.nama;
        if (p.nama === provLama) o.selected = true;
        selProv.appendChild(o);
    });
    selProv.addEventListener('change', () => isiKabupaten(selProv.value, ''));
    if (provLama) isiKabupaten(provLama, kabLama);
</script>
<?php include 'footer.php'; ?>
