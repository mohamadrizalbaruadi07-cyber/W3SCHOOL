-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 20, 2026 at 07:42 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `belajar_web`
--

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE `kategori` (
  `id` int(11) NOT NULL,
  `slug` varchar(40) NOT NULL,
  `nama` varchar(60) NOT NULL,
  `deskripsi` varchar(160) NOT NULL DEFAULT '',
  `warna` varchar(7) NOT NULL DEFAULT '#2f6fed'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`id`, `slug`, `nama`, `deskripsi`, `warna`) VALUES
(1, 'python', 'Python', 'Bahasa serbaguna untuk web, data, dan otomatisasi.', '#3776ab'),
(2, 'sql', 'SQL', 'Bahasa untuk mengambil dan mengelola data di database.', '#d9822b'),
(3, 'java', 'Java', 'Bahasa berorientasi objek untuk aplikasi dan Android.', '#c0392b'),
(4, 'javascript', 'JavaScript', 'Bahasa yang membuat halaman web bisa berinteraksi.', '#c9a400'),
(5, 'css', 'CSS', 'Bahasa untuk mengatur tampilan halaman web.', '#2965f1');

-- --------------------------------------------------------

--
-- Table structure for table `materi`
--

CREATE TABLE `materi` (
  `id` int(11) NOT NULL,
  `id_kategori` int(11) NOT NULL,
  `judul` varchar(150) NOT NULL,
  `isi` mediumtext NOT NULL,
  `kode_contoh` mediumtext DEFAULT NULL,
  `urutan` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `materi`
--

INSERT INTO `materi` (`id`, `id_kategori`, `judul`, `isi`, `kode_contoh`, `urutan`) VALUES
(1, 1, 'Pengenalan Python', '<p>Python adalah bahasa pemrograman yang dikenal mudah dibaca. Python dipakai untuk membuat situs web, menganalisis data, dan mengotomatiskan tugas.</p><p>Program Python ditulis baris demi baris. Perintah <code>print()</code> menampilkan teks ke layar.</p>', 'print(\"Halo, dunia!\")', 1),
(2, 1, 'Variabel dan Tipe Data', '<p>Variabel adalah wadah untuk menyimpan nilai. Di Python, variabel dibuat dengan tanda <code>=</code> tanpa perlu menulis tipenya.</p><p>Tipe data yang sering dipakai: teks (<code>str</code>), bilangan bulat (<code>int</code>), dan bilangan desimal (<code>float</code>).</p>', 'nama = \"Sari\"\numur = 17\nprint(nama, \"berumur\", umur)', 2),
(3, 2, 'Pengenalan SQL', '<p>SQL (Structured Query Language) dipakai untuk berbicara dengan database. Data disimpan dalam tabel yang terdiri dari baris dan kolom.</p><p>Perintah <code>SELECT</code> mengambil data dari tabel.</p>', 'SELECT * FROM siswa;', 1),
(4, 2, 'SELECT dan WHERE', '<p><code>SELECT</code> memilih kolom yang ingin ditampilkan. <code>WHERE</code> menyaring baris sesuai syarat.</p>', 'SELECT nama FROM siswa WHERE kelas = \'X\';', 2),
(5, 3, 'Pengenalan Java', '<p>Java adalah bahasa berorientasi objek yang dipakai untuk aplikasi desktop, server, dan Android. Setiap program Java berada di dalam sebuah <em>class</em>, dan dijalankan dari method <code>main</code>.</p>', 'public class Main {\n    public static void main(String[] args) {\n        System.out.println(\"Halo, dunia!\");\n    }\n}', 1),
(6, 3, 'Variabel di Java', '<p>Java mewajibkan kita menulis tipe data saat membuat variabel, misalnya <code>int</code> untuk bilangan bulat dan <code>String</code> untuk teks.</p>', 'int umur = 17;\nString nama = \"Sari\";\nSystem.out.println(nama + \" berumur \" + umur);', 2),
(7, 4, 'Pengenalan JavaScript', '<p>JavaScript berjalan di browser dan membuat halaman web bisa merespons klik, mengisi formulir, dan menampilkan data tanpa memuat ulang halaman.</p>', 'console.log(\"Halo, dunia!\");', 1),
(8, 4, 'Variabel: let dan const', '<p>Gunakan <code>let</code> untuk nilai yang bisa berubah, dan <code>const</code> untuk nilai yang tetap.</p>', 'const nama = \"Sari\";\nlet umur = 17;\numur = umur + 1;\nconsole.log(nama, umur);', 2),
(9, 5, 'Pengenalan CSS', '<p>CSS (Cascading Style Sheets) mengatur warna, ukuran, dan tata letak elemen HTML. Aturan CSS terdiri dari <em>selektor</em> dan blok properti.</p>', '<style>\n  p { color: #c0392b; font-size: 20px; }\n</style>\n<p>Teks ini berwarna merah.</p>', 1),
(10, 5, 'Selektor CSS', '<p>Selektor menentukan elemen mana yang diberi gaya: nama elemen (<code>p</code>), kelas (<code>.judul</code>), atau id (<code>#utama</code>).</p>', '<style>\n  .judul { color: #2965f1; }\n  #utama { background: #eef3ff; padding: 10px; }\n</style>\n<div id=\"utama\">\n  <h2 class=\"judul\">Halo CSS</h2>\n</div>', 2);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `nama` varchar(200) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(255) NOT NULL,
  `Provinsi` varchar(100) DEFAULT NULL,
  `Kabupaten` varchar(100) DEFAULT NULL,
  `role` enum('admin','pelajar') NOT NULL DEFAULT 'pelajar',
  `last_login` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `nama`, `username`, `password`, `Provinsi`, `Kabupaten`, `role`, `last_login`) VALUES
(6, 'tika', 'gg', '2af54305f183778d87de0c70c591fae4', NULL, NULL, 'pelajar', NULL),
(7, 'aing', 'maung', '81dc9bdb52d04dc20036dbd8313ed055', NULL, NULL, 'pelajar', NULL),
(8, 'rizal', 'jalo', '81dc9bdb52d04dc20036dbd8313ed055', NULL, NULL, 'pelajar', NULL),
(9, 'jessi', 'dwiwoy', '81dc9bdb52d04dc20036dbd8313ed055', NULL, NULL, 'pelajar', NULL),
(10, 'jall', 'ijalll', '81dc9bdb52d04dc20036dbd8313ed055', 'Gorontalo', 'Kota Gorontalo', 'pelajar', NULL),
(11, 'fajriansyah', 'gigi', '$2y$10$pQ5aeMVTBxppO7rGXgqKHexx3fuadvbOKB1T2//xY5GtLnqJpGnOG', 'Gorontalo', 'Kota Gorontalo', 'admin', '2026-11-20 14:32:19');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`);

--
-- Indexes for table `materi`
--
ALTER TABLE `materi`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_kategori` (`id_kategori`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `kategori`
--
ALTER TABLE `kategori`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `materi`
--
ALTER TABLE `materi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `materi`
--
ALTER TABLE `materi`
  ADD CONSTRAINT `materi_ibfk_1` FOREIGN KEY (`id_kategori`) REFERENCES `kategori` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
